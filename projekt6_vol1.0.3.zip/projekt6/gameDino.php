<?php
include_once 'header.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/dino.css">
    
</head>
<body>

    <div id="game">
        <img id="bg" src="icons/dinoIcons/path.png">
        <img id="character" src="icons/dinoIcons/dinoJump.png">
        <img id="block" src="icons/dinoIcons/cactusBall.png">
    </div>
<p> Score: <span id="scoreSpan"></span></p>

<p><input type="button" value="JUMP!" class="jumpBtn" onclick="jump()"></p>

<script src="js/gameDino.js"></script>

</body>
</html>