<?php
include_once 'header.php';
?>

<section class="signup-form">
    <h2>Welcome in our page!</h2>
    <!-- co to właściwie jest te signup.inc.php? ".inc" ma onzazcać include. nie wpływa na ścieżkę.
    Kropkę można zastąpić np. myślnikiem signup-inc.php także no. Wiesz co jest 5.-->
    <div class = "signupPanel"> 
        <form action="includes/signup.inc.php" method="post">
            <input type="text" name="name" placeholder="Eneter name...">
            <input type="text" name="email" placeholder="Eneter email...">
            <input type="text" name="uid" placeholder="Eneter Username...">
            <input type="password" name="pwd" placeholder="Eneter password...">
            <input type="password" name="pwdRepeat" placeholder="Re-enter password...">
            <button type="submit" name="submit">Sign Up</button>
        </form>
    </div>
        <div class="alreadyRegistered">
            <p>Already got an accout? Let's <a href="login.php">log in!</a>
        </div>
    <?php
if(isset($_GET["error"]))
{
    if($_GET["error"] == "emptyinput")
    {
        echo "<p>Fill in all fields!</p>";
    }
    else if($_GET["error"] == "invaliduid")
    {
        echo "<p>Error in username section!</p>";
    }
    else if($_GET["error"] == "invalidemail")
    {
        echo "<p>Error in e-mail section!</p>";
    }
    else if($_GET["error"] == "passwordsdontmatch")
    {
        echo "<p>Error! Password doesn't match!</p>";
    }
    else if($_GET["error"] == "stmtfailed")
    {
        echo "<p>Something went wrong! S O M E T H I N G is T O T A L Y  NOT YES!</p>";
    }
    else if($_GET["error"] == "usernametaken")
    {
        echo "<p>Username already taken!</p>";
    }
    else if($_GET["error"] == "none")
    {
        echo "<p>You have signed up!</p>";
    }
}
?>

</section>

<?php
include_once 'footer.php';
?>