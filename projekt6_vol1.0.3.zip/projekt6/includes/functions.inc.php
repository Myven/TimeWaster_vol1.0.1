<?php

// !ERROR NA PUSTE MIEJSCE FORMULARZA! result zwraca true/false funkcji emptyInputSignup 

function emptyInputSignup($name, $email, $username, $pwd, $pwdRepeat) 
{
    $result;
    if(empty($name) || empty($email) || empty($username) || empty($pwd) || empty($pwdRepeat))
    {
        $result = true;
    }
    else
    {
        $result = false;
    }
    return $result;
}

/* !WYKLUCZENIE ZNAKÓW SPECJALNYCH! preg_match jest wpisany w php. Sprawdza poprawność 
wpisanych danych (np. wykluczamy znaki specjalne i jeżeli ktoś w formularzu wpisze znak specjalny
powinno wyrzućić błąd.) Pierwszy parametr "/^[a-zA-Z0-9]*$/" pozwala na stosowanie
małych i wielkich liter oraz cyfr.*/
function invalidUid($username) 
{
    $result;
    if(!preg_match("/^[a-zA-Z0-9]*$/", $username))
    {
        $result = true;
    }
    else
    {
        $result = false;
    }
    return $result;
}

/* !FILTR SPRAWDZAJĄCY POPRAWNOŚĆ MAILA! !filter_var($email, FILTER_VALIDATE_EMAIL to statement
wbudowany w PHP do weryfikacji maila. To filtr który sprawdza wpisany parametr w tym przyapdku
email czyli potrzebny znak "@" i "." i zwraca jako true. Jako że najpierw sprawdzam error
funkcję poprzedza ! tak aby zanegować działanie i nie zwróciło TRUE */
function invalidEmail($email) 
{
    $result;
    if(!filter_var($email, FILTER_VALIDATE_EMAIL))
    {
        $result = true;
    }
    else
    {
        $result = false;
    }
    return $result;
}

//Sprawdzenie poprawności obu haseł jeżeli jedno nierówne drugiemu zwraca błą czyli TRUE
function pwdMatch($pwd, $pwdRepeat) 
{
    $result;
    if($pwd !== $pwdRepeat)
    {
        $result = true;
    }
    else
    {
        $result = false;
    }
    return $result;
}

// ? w zapytaniu do bazy to placeholder
function uidExists($conn, $username, $email)
{
    $sql = "SELECT * FROM users WHERE usersUid = ? OR usersEmail = ?;";
    $stmt = mysqli_stmt_init($conn);
    if(!mysqli_stmt_prepare($stmt, $sql))
    {
        header("location: ../signup.php?error=stmtfailed");
        exit();
    }

    mysqli_stmt_bind_param($stmt, "ss", $username, $email);
    mysqli_stmt_execute($stmt);

    $resultData = mysqli_stmt_get_result($stmt);

    if($row = mysqli_fetch_assoc($resultData))
    {
        return $row;
    }
    else
    {
        $result = false;
        return $result;
    }

mysqli_stmt_close($stmt);

}

function createUser($conn, $name, $email, $username, $pwd)
{
    $sql = "INSERT INTO users (usersName,  usersEmail, usersUid, usersPwd) VALUES (?, ?, ?, ?);";
    $stmt = mysqli_stmt_init($conn);
    if(!mysqli_stmt_prepare($stmt, $sql))
    {
        header("location: ../signup.php?error=stmtfailed");
        exit();
    }

//zabezpieczenie haseł hashowaniem automatycznie się aktualizuje

    $hashedPwd = password_hash($pwd, PASSWORD_DEFAULT);

//ssss litery odpowiadają ilości danych, w tym przypadku 4 ponieważ podajemy uname, uemail, uid, upwd
    
    mysqli_stmt_bind_param($stmt,"ssss", $name, $email, $username, $hashedPwd ); 
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
    header("location: ../signup.php?error=none");
    exit();
}

function emptyInputLogin($username, $pwd) 
{
    $result;
    if(empty($username) || empty($pwd))
    {
        $result = true;
    }
    else
    {
        $result = false;
    }
    return $result;
}
function loginUser($conn, $username, $pwd) 
{
    $uidExists = uidExists($conn, $username, $username);

    if ($uidExists === false)
    {
        header("location: ../login.php?error=wronglogin");
        exit();
    }

    $pwdHashed = $uidExists["usersPwd"];
    $checkPwd = password_verify($pwd, $pwdHashed);

    if($checkPwd === false)
    {
        header("location: ../login.php?error=wronglogin");
        exit();
    }
    else if($checkPwd === true)
    {
        session_start();
        $_SESSION["userid"] = $uidExists["usersId"];
        $_SESSION["useruid"] = $uidExists["usersUid"];
        header("location: ../profile.php");
        exit();
    }
}

