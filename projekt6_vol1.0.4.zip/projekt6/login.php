<?php
include_once 'header.php';
?>

<section class="signup-form">
    <h2>Log In</h2>
    <!-- co to właściwie jest te signup.inc.php? ".inc" ma onzazcać include. nie wpływa na ścieżkę.
    Kropkę można zastąpić np. myślnikiem signup-inc.php także no. Wiesz co jest 5.-->
    <div class = "signupPanel"> 
        <form action="includes/login.inc.php" method="post">
            <input type="text" name="uid" placeholder="Eneter Username/Email...">
            <input type="password" name="pwd" placeholder="Eneter password...">
            <button type="submit" name="submit">Log In</button>
        </form>
    </div>
    <div class="notRegistered">
    <p>Haven't got an accout yet? <a href='signup.php'>Create one!</a></p>
    <div>
<?php
if(isset($_GET["error"]))
{
    if($_GET["error"] == "emptyinput")
    {
        echo "<p>Fill in all fields!</p>";
    }
    else if($_GET["error"] == "wronglogin")
    {
        echo "<p>Incorrect login!</p>";
    }
}
?>
</section>

<?php
include_once 'footer.php';
?>