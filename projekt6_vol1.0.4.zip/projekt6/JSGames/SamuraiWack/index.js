const canvas = document.querySelector('canvas')
const c = canvas.getContext('2d')

//canvas window measures
canvas.width = 1024
canvas.height = 576

//gravity blocks movement and block (player/enemy) info like height/position/movement velocity
c.fillRect(0, 0, canvas.width, canvas.height)
const gravity = 0.7

//background placement
const background = new Sprite({
    position: {
        x: 0,
        y: 0
    },
    imageSrc: './Assets/images/background/nicebg.png'
})

//shop placement and animation
const shop = new Sprite({
    position: {
        x: 670,
        y: 219
    },
    imageSrc: './Assets/images/decorations/shop_anim.png',
    scale: 2.3,
    framesMax: 6
})

//character start position
const player = new Fighter({
    position: {
    x:0,
    y:0
},
velocity:{
    x: 0,
    y: 0
},
offset: {
    x: -200,
    y: 0
},
imageSrc: './Assets/images/character/Martial_Hero/Sprites/Idle.png',
framesMax: 8,
scale: 2.1,
offset: {
    x: 115,
    y: 108
},
sprites: {
    idle: {
        imageSrc: './Assets/images/character/Martial_Hero/Sprites/Idle.png',
        framesMax: 8
    },
    idleHurt: {
        imageSrc: './Assets/images/character/Martial_Hero/Sprites/IdleHurt.png',
        framesMax: 8
    },
    idleHurtBadly: {
        imageSrc: './Assets/images/character/Martial_Hero/Sprites/IdleHurtBadly.png',
        framesMax: 8
    },
    idleHurtBadly2: {
        imageSrc: './Assets/images/character/Martial_Hero/Sprites/IdleHurtBadly2.png',
        framesMax: 8
    },
    idleHurtBadly3: {
        imageSrc: './Assets/images/character/Martial_Hero/Sprites/IdleHurtBadly3.png',
        framesMax: 8
    },
    run: {
        imageSrc: './Assets/images/character/Martial_Hero/Sprites/Run.png',
        framesMax: 8
    },
    jump: {
        imageSrc: './Assets/images/character/Martial_Hero/Sprites/Jump.png',
        framesMax: 2
    },
    fall: {
        imageSrc: './Assets/images/character/Martial_Hero/Sprites/Fall.png',
        framesMax: 2
    },
    attack1: {
        imageSrc: './Assets/images/character/Martial_Hero/Sprites/myAttack5.png',
        framesMax: 4
    }, 
    takeHit: {
        imageSrc: './Assets/images/character/Martial_Hero/Sprites/Take Hit - white silhouette2.png',
        framesMax: 4
    },
    death: {
        imageSrc: './Assets/images/character/Martial_Hero/Sprites/Death6.png',
        framesMax: 11,
    },
    win: {
        imageSrc: './Assets/images/character/Martial_Hero/Sprites/Win4.png',
        framesMax: 13,
    }
},
attackBox: {
    offset: {
        x: 120,
        y: 50
    },
    width: 160,
    height: 50
}
})

//enemy start position

const enemy = new Fighter({
    position: {
    x:650,
    y:100
},
velocity:{
    x: 0,
    y: 0
},
color: 'blue',
offset: {
    x: -50,
    y: 0
},
imageSrc: './Assets/images/character/Martial_Hero_2/Sprites/Idle.png',
framesMax: 4,
scale: 2.3,
offset: {
    x: 215,
    y: 147
},
sprites: {
    idle: {
        imageSrc: './Assets/images/character/Martial_Hero_2/Sprites/Idle.png',
        framesMax: 4
    },
    run: {
        imageSrc: './Assets/images/character/Martial_Hero_2/Sprites/Run.png',
        framesMax: 8
    },
    jump: {
        imageSrc: './Assets/images/character/Martial_Hero_2/Sprites/Jump.png',
        framesMax: 2
    },
    fall: {
        imageSrc: './Assets/images/character/Martial_Hero_2/Sprites/Fall.png',
        framesMax: 2
    },
    attack1: {
        imageSrc: './Assets/images/character/Martial_Hero_2/Sprites/myAttack1_1.png',
        framesMax: 4,
    },    
    takeHit: {
        imageSrc: './Assets/images/character/Martial_Hero_2/Sprites/Take_hit6.png',
        framesMax: 3,
    },
    death: {
        imageSrc: './Assets/images/character/Martial_Hero_2/Sprites/Death.png',
        framesMax: 7
    }
},
attackBox: {
    offset: {
        x: -230,
        y: 50
    },
    width: 150,
    height: 50
}
})

enemy.draw()

console.log(player)

//clean, well optimized movment. i swear... +
//background color drawing with canvas width/height and player/enemy spawn
const keys = {
    a: {
        pressed: false
    },
    d: {
        pressed: false
    },
    w: {
        pressed: false
    },
    ArrowRight: {
        pressed: false
    },
    ArrowLeft: {
        pressed: false
    },
    ArrowUp: {
        pressed: false
    }
}

decreaseTimer()

function animate() {
    window.requestAnimationFrame(animate)
    c.fillStyle= 'black'
    c.fillRect(0, 0, canvas.width, canvas.height)
    background.update()
    shop.update()
    c.fillStyle = 'rgba(255, 255, 255, 0.15)'
    c.fillRect(0, 0, canvas.width, canvas.height)
    player.update()
    enemy.update()

    //preventing infinite movment afer clicking left/right (ArrowLeft/Right, a/d)
    player.velocity.x = 0
    enemy.velocity.x=0

    //player movement
  
    if (keys.a.pressed && player.lastKey === 'a') {
        player.velocity.x = -5
        player.switchSprite('run')
    } else if (keys.d.pressed && player.lastKey === 'd') {
        player.velocity.x = 5
        player.switchSprite('run')
    } 
     //If player got less than 90 HP changes skin to idleHurt
    else if(player.health < 90 && player.health > 70){
        player.switchSprite('idleHurt')
    } else if(player.health < 70 && player.health > 50){
        player.switchSprite('idleHurtBadly')
    } else if(player.health < 50 && player.health > 30){
        player.switchSprite('idleHurtBadly2')
    } else if(player.health < 30 && player.health > 0){
        player.switchSprite('idleHurtBadly3')
    } else if(enemy.health <= 0){
         player.switchSprite('win')
         player.playerWin()
    } else {
        player.switchSprite('idle')
    }

    //jumping player
    if (player.velocity.y < 0) {
        player.switchSprite('jump')
    } else if (player.velocity.y > 0) {
        player.switchSprite('fall')
    }

    //enemy movement
    if (keys.ArrowLeft.pressed && enemy.lastKey === 'ArrowLeft') {
        enemy.velocity.x = -5
        enemy.switchSprite('run')
    } else if (keys.ArrowRight.pressed && enemy.lastKey === 'ArrowRight') {
        enemy.velocity.x = 5
        enemy.switchSprite('run')
    } else {
        enemy.switchSprite('idle')
    }

       //jumping enemy
       if (enemy.velocity.y < 0) {
        enemy.switchSprite('jump')
    } else if (enemy.velocity.y > 0) {
        enemy.switchSprite('fall')
    }

    //Collision detect & enemy gets hit
    if(rectangularCollision({
        rectangle1: player,
        rectangle2: enemy
    }) &&
    player.isAttacking &&
    player.framesCurrent === 2 
        ){
            enemy.takeHit()
            player.isAttacking = false


           gsap.to('#enemyHealth', {
            width: enemy.health + '%'
           })
    }

      // if player misses
      if (player.isAttacking && player.framesCurrent === 2) {
        player.isAttacking = false
    }
    // where player gets hit
    if(rectangularCollision({
        rectangle1: enemy,
        rectangle2: player
    }) &&
    enemy.isAttacking && enemy.framesCurrent === 2
        ){
            player.takeHit()
            enemy.isAttacking = false

            gsap.to('#playerHealth', {
            width: player.health + '%'
            })
        }
    // if enemy misses
    if (enemy.isAttacking && enemy.framesCurrent === 2) {
        enemy.isAttacking = false
    }

    //end game based on health
    if (enemy.health <= 0 || player.health <= 0)
    {
        determineWinner({player, enemy, timerId})
    }
}

animate()
//movement lefr/right on keydown
window.addEventListener('keydown', (event) => {
    if (!player.dead && !player.win){
    
    switch (event.key) {
        case 'd':
        keys.d.pressed = true
        player.lastKey = 'd'
        break
        case 'a':
        keys.a.pressed = true
        player.lastKey = 'a'
        break
        case 'w':
        player.velocity.y = -20
        break
        case ' ':
        player.attack()
        break
    }
}
if(!enemy.dead && !enemy.win) {
    switch (event.key) {
        case 'ArrowRight':
        keys.ArrowRight.pressed = true
        enemy.lastKey = 'ArrowRight'
        break
        case 'ArrowLeft':
        keys.ArrowLeft.pressed = true
        enemy.lastKey = 'ArrowLeft'
        break
        case 'ArrowUp':
        enemy.velocity.y = -20
        break
        case 'ArrowDown':
        enemy.attack()
        break
    }
}
})

//character stopper. If you stop holding a/d key down character stops.

window.addEventListener('keyup', (event) => {
    switch (event.key) {
        case 'd':
        keys.d.pressed = false
        break
        case 'a':
        keys.a.pressed = false
        break
        case 'w':
        keys.w.pressed = false
        break
    }

    //enemy keys
    switch (event.key) {
        case 'ArrowRight':
        keys.ArrowRight.pressed = false
        break
        case 'ArrowLeft':
        keys.ArrowLeft.pressed = false
        break
        case 'ArrowUp':
        keys.ArrowUp.pressed = false
        break
    }
})