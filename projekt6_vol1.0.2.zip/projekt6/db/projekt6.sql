-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 23, 2023 at 09:30 AM
-- Wersja serwera: 10.4.28-MariaDB
-- Wersja PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `projekt6`
--

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `users`
--

CREATE TABLE `users` (
  `usersId` int(11) NOT NULL,
  `usersName` varchar(128) NOT NULL,
  `usersEmail` varchar(128) NOT NULL,
  `usersUid` varchar(128) NOT NULL,
  `usersPwd` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_polish_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`usersId`, `usersName`, `usersEmail`, `usersUid`, `usersPwd`) VALUES
(1, 'Devolaile Mitsosig', 'dawid@dawid.pl', 'Koulibaly', '$2y$10$gmXno5yEgPQORhk2vPViKOMYMbk1rZzygBIShOjLoAdg2KpirPpdi'),
(2, 'Agent Buczkov', 'buczoses@agnt.securitylevelhard', 'Buczoses', '$2y$10$kSNjDwkm4NaEhCFakl5wnum7CoUQyEyvGcE6SI2m9Ie2ruL0wI34q'),
(3, 'Dawid ', 'zineroTX@gmail.com', 'Myven', '$2y$10$xuPbSfUrZKClD5/vyq4qEujTGeUN./ivPOtp2Fx32CKa8rSKhb7Ii'),
(4, 'jarek', 'jarek@gmail.com', 'skwarek', '$2y$10$IRFMw3KfgvX7YpbmQ6oPYO8e.fVWPtgO5QAE/9LVnYFlObaFSriiC'),
(5, 'Mike Oxlong', 'mikeox@long.com', 'kakuzu123', '$2y$10$tQzFPEhubMBc0FMPYPJuOujje3HVEVmeY6oIbvt.Ci/7sO1rOzv7O'),
(6, 'zinero2', 'zinero2@interia.pl', 'Zinero2', '$2y$10$blngNX3/MosOwUXTvszTfe2jJGhs9dBTM5qtsUC8MZqYMGEC/d5KK'),
(7, 'malgo', 'malgo@source.cs', 'malgo', '$2y$10$yzsfw1Y3vBL.DwxRboFH5.YnRpRE4QKE6ZPsx74hN9zHK4sOxvc6u');

--
-- Indeksy dla zrzutów tabel
--

--
-- Indeksy dla tabeli `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`usersId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `usersId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
