<?php
include_once 'header.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Game Section</title>
    <link rel="stylesheet" href="css/gameSection.css">
</head>
<body>
    <div class="gameSection">
    <?php
                if(isset($_SESSION["useruid"]))
                {
                    echo "<h3>Welcome in our Gaming Section " . $_SESSION["useruid"] . "!</h3>";
                }
                else
                {
                    echo "<p>Want to use our website? You need to be <a href='login.php'>logged in!</a></p>";
                    echo "<p>Haven't got an accout yet? <a href='signup.php'>Create one!</a></p>";
                }
            ?>
        <div calss="gameDinoSection">
                <a href="gameDino.php"><img src="icons/dinoIcons/dinoLogo.png"></a>
                <p>Jumping Dino!</p>
        </div>
        <div calss="gameSamuraiSection">
                <a href="js/SamuraiWack/gameSamurai.php"><img src="icons/samuraiIcons/samuraiLogo.png"></a>
                <p>Samurai duel!</p>
        </div>
    </div>
</body>
</html>