<?php
include_once 'header.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<?php
                if(isset($_SESSION["useruid"]))
                {
                    echo "<h3>Welcome in your profile page " . $_SESSION["useruid"] . "!</h3>";
                }
                else
                {
                    echo "<p><a href='signup.php'>Sign up</a></p>";
                    echo "<p><a href='login.php'>Log in</a></p>";
                }
            ?>
</body>
</html>