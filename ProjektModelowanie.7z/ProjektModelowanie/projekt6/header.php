<?php
    session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Grzegorz Floryda Enterprises</title>
    <link rel="stylesheet" href="css/gfe.css">
</head>
<body>
    <nav>
        <div class = "wrapper">
            <p><a href="index.php">Home</p>
            <?php
            //wykorzystanie sesji przy zalogowanym użytkowniku
            if(isset($_SESSION["useruid"]))
            {
                echo "<p><a href='profile.php'>Your Profile</a></p>";
                echo "<p><a href='includes/logout.inc.php'>Log out</a></p>";
            }
            else
            {
                echo "<p><a href='signup.php'>Sign up</a></p>";
                echo "<p><a href='login.php'>Log in</a></p>";
            }
            ?>
            <div class="gfe">
            <p><a href="https://youtu.be/OX5We0DNhMs?t=44" target="blank">GFE</a></p>
            </div>
        </div>
    </nav>
