const canvas = document.querySelector('canvas')
const c = canvas.getContext('2d')
const ATTACK_COOLDOWN = 0.25;

// Canvas window measures
canvas.width = 1024
canvas.height = 576

// Delta time variables for frame rate independence
let lastTime = 0;
const FPS = 60; // Target frame rate
const frameTime = 1000 / FPS; // Time per frame in milliseconds

// Gravity as a per-second value (original value * 60)
const GRAVITY = 20; // Original 0.7 * 60
const JUMP_FORCE = -600; // Jump velocity as pixels per second
const MOVE_SPEED = 400; // Move speed as pixels per second

// Canvas setup
c.fillRect(0, 0, canvas.width, canvas.height)

// Movement key states
const keys = {
    a: {
        pressed: false
    },
    d: {
        pressed: false
    },
    w: {
        pressed: false
    },
    space: {  // Klucz do śledzenia spacji
        pressed: false
    },
    ArrowRight: {
        pressed: false
    },
    ArrowLeft: {
        pressed: false
    },
    ArrowUp: {
        pressed: false
    },
    ArrowDown: {  // Klucz do śledzenia strzałki w dół
        pressed: false
    }
};

// Background placement
const background = new Sprite({
    position: {
        x: 0,
        y: 0
    },
    imageSrc: './Assets/images/background/nicebg.png'
})

// Shop placement and animation
const shop = new Sprite({
    position: {
        x: 670,
        y: 219
    },
    imageSrc: './Assets/images/decorations/shop_anim.png',
    scale: 2.3,
    framesMax: 6
})

// Character start position
const player = new Fighter({
    position: {
        x: 200,  // Zmienione z 0 dla lepszej widoczności
        y: 0
    },
    velocity: {
        x: 0,
        y: 0
    },
    offset: {
        x: -200,
        y: 0
    },
    imageSrc: './Assets/images/character/Martial_Hero/Sprites/Idle.png',
    framesMax: 8,
    scale: 2.1,
    offset: {
        x: 115,
        y: 108
    },
    sprites: {
        idle: {
            imageSrc: './Assets/images/character/Martial_Hero/Sprites/Idle.png',
            framesMax: 8
        },
        idleHurt: {
            imageSrc: './Assets/images/character/Martial_Hero/Sprites/IdleHurt.png',
            framesMax: 8
        },
        idleHurtBadly: {
            imageSrc: './Assets/images/character/Martial_Hero/Sprites/IdleHurtBadly.png',
            framesMax: 8
        },
        idleHurtBadly2: {
            imageSrc: './Assets/images/character/Martial_Hero/Sprites/IdleHurtBadly2.png',
            framesMax: 8
        },
        idleHurtBadly3: {
            imageSrc: './Assets/images/character/Martial_Hero/Sprites/IdleHurtBadly3.png',
            framesMax: 8
        },
        run: {
            imageSrc: './Assets/images/character/Martial_Hero/Sprites/Run.png',
            framesMax: 8
        },
        jump: {
            imageSrc: './Assets/images/character/Martial_Hero/Sprites/Jump.png',
            framesMax: 2
        },
        fall: {
            imageSrc: './Assets/images/character/Martial_Hero/Sprites/Fall.png',
            framesMax: 2
        },
        attack1: {
            imageSrc: './Assets/images/character/Martial_Hero/Sprites/Attack1.png',
            framesMax: 6
        }, 
        takeHit: {
            imageSrc: './Assets/images/character/Martial_Hero/Sprites/Take Hit - white silhouette2.png',
            framesMax: 4
        },
        death: {
            imageSrc: './Assets/images/character/Martial_Hero/Sprites/Death6.png',
            framesMax: 11,
        },
        win: {
            imageSrc: './Assets/images/character/Martial_Hero/Sprites/Win4.png',
            framesMax: 13,
        }
    },
    attackBox: {
        offset: {
            x: 120,
            y: 50
        },
        width: 160,
        height: 50
    }
})

// Enemy start position
const enemy = new Fighter({
    position: {
        x: 750,  // Zmienione z 650 dla lepszej widoczności
        y: 100
    },
    velocity: {
        x: 0,
        y: 0
    },
    color: 'blue',
    offset: {
        x: -50,
        y: 0
    },
    imageSrc: './Assets/images/character/Martial_Hero_2/Sprites/Idle.png',
    framesMax: 4,
    scale: 2.1,
    offset: {
        x: 215,
        y: 120
    },
    sprites: {
        idle: {
            imageSrc: './Assets/images/character/Martial_Hero_2/Sprites/Idle.png',
            framesMax: 4
        },
        run: {
            imageSrc: './Assets/images/character/Martial_Hero_2/Sprites/Run.png',
            framesMax: 8
        },
        jump: {
            imageSrc: './Assets/images/character/Martial_Hero_2/Sprites/Jump.png',
            framesMax: 2
        },
        fall: {
            imageSrc: './Assets/images/character/Martial_Hero_2/Sprites/Fall.png',
            framesMax: 2
        },
        attack1: {
            imageSrc: './Assets/images/character/Martial_Hero_2/Sprites/myAttack1_2.png',
            framesMax: 6,
        },    
        takeHit: {
            imageSrc: './Assets/images/character/Martial_Hero_2/Sprites/Take_hit8.png',
            framesMax: 4,
        },
        death: {
            imageSrc: './Assets/images/character/Martial_Hero_2/Sprites/Death.png',
            framesMax: 7
        },
        clash: {
            imageSrc: './Assets/images/character/Martial_Hero_2/Sprites/clash.png',
            framesMax: 1
        }
    },
    attackBox: {
        offset: {
            x: -230,
            y: 50
        },
        width: 150,
        height: 50
    }
})

// Initialize enemy
enemy.draw()

// Start the timer
decreaseTimer()

// Start animation loop
animate();

// Main game loop with frame rate independence
function animate(currentTime = 0) {
    // Obliczanie deltaTime w sekundach
    const deltaTime = (currentTime - lastTime) / 1000;
    
    // Ograniczamy deltaTime, aby uniknąć skoków po pauzie/przełączeniu kart
    const cappedDeltaTime = Math.min(deltaTime, 0.25);
    
    // Zapisz aktualny czas dla następnej klatki
    lastTime = currentTime;
    
    // Żądanie następnej klatki animacji
    window.requestAnimationFrame(animate);
    
    // Wyczyszczenie płótna
    c.fillStyle = 'black';
    c.fillRect(0, 0, canvas.width, canvas.height);
    
    // Aktualizacja elementów tła
    background.update(cappedDeltaTime);
    shop.update(cappedDeltaTime);
    
    // Overlay
    c.fillStyle = 'rgba(255, 255, 255, 0.15)';
    c.fillRect(0, 0, canvas.width, canvas.height);
    
    // Resetowanie prędkości
    player.velocity.x = 0;
    enemy.velocity.x = 0;
    
    // Sprawdź czy postać może się poruszać (nie jest w trakcie ataku)
    const playerCanMove = !player.attackInProgress;
    const enemyCanMove = !enemy.attackInProgress;

    // RUCH GRACZA
    if (playerCanMove) {
        if (keys.a.pressed && player.lastKey === 'a') {
            player.velocity.x = -MOVE_SPEED * cappedDeltaTime;
            player.switchSprite('run');
        } else if (keys.d.pressed && player.lastKey === 'd') {
            player.velocity.x = MOVE_SPEED * cappedDeltaTime;
            player.switchSprite('run');
        } 
        // Zmiana spritu na podstawie zdrowia pozostaje bez zmian
        else if(player.health < 90 && player.health > 70) {
            player.switchSprite('idleHurt');
        } else if(player.health < 70 && player.health > 50) {
            player.switchSprite('idleHurtBadly');
        } else if(player.health < 50 && player.health > 30) {
            player.switchSprite('idleHurtBadly2');
        } else if(player.health < 30 && player.health > 0) {
            player.switchSprite('idleHurtBadly3');
        } else if(enemy.health <= 0) {
            player.switchSprite('win');
            player.playerWin();
        } else {
            player.switchSprite('idle');
        }
    } else {
        // Jeśli postać jest w trakcie ataku, zresetuj prędkość
        player.velocity.x = 0;
    }
    
    // Skakanie gracza - pozostaw bez zmian (skok dozwolony podczas ataku)
    if (player.velocity.y < 0) {
        player.switchSprite('jump');
    } else if (player.velocity.y > 0) {
        player.switchSprite('fall');
    }
    
    // RUCH PRZECIWNIKA
    if (enemyCanMove) {
        if (keys.ArrowLeft.pressed && enemy.lastKey === 'ArrowLeft') {
            enemy.velocity.x = -MOVE_SPEED * cappedDeltaTime;
            enemy.switchSprite('run');
        } else if (keys.ArrowRight.pressed && enemy.lastKey === 'ArrowRight') {
            enemy.velocity.x = MOVE_SPEED * cappedDeltaTime;
            enemy.switchSprite('run');
        } else {
            enemy.switchSprite('idle');
        }
    } else {
        // Jeśli przeciwnik jest w trakcie ataku, zresetuj prędkość
        enemy.velocity.x = 0;
    }
    
    // Skakanie przeciwnika - pozostaw bez zmian (skok dozwolony podczas ataku)
    if (enemy.velocity.y < 0) {
        enemy.switchSprite('jump');
    } else if (enemy.velocity.y > 0) {
        enemy.switchSprite('fall');
    }

    // Sprawdź czy przycisk ataku jest wciśnięty i czy można wykonać atak
    if (keys.space && keys.space.pressed) {
        player.attack();
    }
    
    if (keys.ArrowDown && keys.ArrowDown.pressed) {
        enemy.attack();
    }

    // Aktualizacja graczy z delta time
    player.update(cappedDeltaTime);
    enemy.update(cappedDeltaTime);

    // WYKRYWANIE KOLIZJI
    // Gracz uderza przeciwnika
    if (
        rectangularCollision({
            rectangle1: player,
            rectangle2: enemy
        }) &&
        player.isAttacking
    ) {
        enemy.takeHit();
        player.isAttacking = false; // Zapobiega wielokrotnym trafieniom w jednym ataku

        gsap.to('#enemyHealth', {
            width: enemy.health + '%'
        });
    }
    
    // Przeciwnik uderza gracza
    if (
        rectangularCollision({
            rectangle1: enemy,
            rectangle2: player
        }) &&
        enemy.isAttacking
    ) {
        player.takeHit();
        enemy.isAttacking = false; // Zapobiega wielokrotnym trafieniom w jednym ataku
    
        gsap.to('#playerHealth', {
            width: player.health + '%'
        });
    }

    // Koniec gry na podstawie zdrowia
    if (enemy.health <= 0 || player.health <= 0) {
        determineWinner({player, enemy, timerId});
    }
}

// KEYBOARD CONTROLS
window.addEventListener('keydown', (event) => {
    if (!player.dead && !player.win) {
        switch (event.key) {
            case 'd':
                keys.d.pressed = true;
                player.lastKey = 'd';
                break;
            case 'a':
                keys.a.pressed = true;
                player.lastKey = 'a';
                break;
            case 'w':
                // Skok tylko gdy na ziemi
                if (player.position.y === 362) {
                    player.velocity.y = JUMP_FORCE * (1/60);
                }
                break;
            case ' ':
                // Bezpośrednie wywołanie ataku
                player.attack();
                // Śledzenie wciśnięcia przycisku dla obsługi zapętlania
                keys.space.pressed = true;
                break;
        }
    }
    
    if (!enemy.dead && !enemy.win) {
        switch (event.key) {
            case 'ArrowRight':
                keys.ArrowRight.pressed = true;
                enemy.lastKey = 'ArrowRight';
                break;
            case 'ArrowLeft':
                keys.ArrowLeft.pressed = true;
                enemy.lastKey = 'ArrowLeft';
                break;
            case 'ArrowUp':
                // Skok tylko gdy na ziemi
                if (enemy.position.y === 362) {
                    enemy.velocity.y = JUMP_FORCE * (1/60);
                }
                break;
            case 'ArrowDown':
                // Bezpośrednie wywołanie ataku
                enemy.attack();
                // Śledzenie wciśnięcia przycisku dla obsługi zapętlania
                keys.ArrowDown.pressed = true;
                break;
        }
    }
});

// Obsługa puszczenia klawiszy
window.addEventListener('keyup', (event) => {
    switch (event.key) {
        case 'd':
            keys.d.pressed = false;
            break;
        case 'a':
            keys.a.pressed = false;
            break;
        case 'w':
            keys.w.pressed = false;
            break;
        case ' ':
            keys.space.pressed = false;
            break;
        case 'ArrowRight':
            keys.ArrowRight.pressed = false;
            break;
        case 'ArrowLeft':
            keys.ArrowLeft.pressed = false;
            break;
        case 'ArrowUp':
            keys.ArrowUp.pressed = false;
            break;
        case 'ArrowDown':
            keys.ArrowDown.pressed = false;
            break;
    }
});