class Sprite {
    constructor({ 
        position,
        imageSrc,
        scale = 1,
        framesMax = 1,
        offset = {x:0, y:0}
    }) {
        this.position = position
        this.width = 50
        this.height = 150
        this.image = new Image()
        this.image.src = imageSrc
        this.scale = scale
        this.framesMax = framesMax
        this.framesCurrent = 0
        this.framesElapsed = 0
        // Teraz framesHold będzie wartością czasu w sekundach
        this.frameDuration = 0.08 // Czas trwania klatki animacji w sekundach
        this.animTimer = 0 // Timer dla klatek animacji
        this.offset = offset
    }
    
    draw() {
        c.drawImage(
            this.image,
            this.framesCurrent * (this.image.width / this.framesMax),
            0,
            this.image.width / this.framesMax,
            this.image.height,
            this.position.x - this.offset.x,
            this.position.y - this.offset.y,
            (this.image.width / this.framesMax) * this.scale,
            this.image.height * this.scale
        )
    }

    // Aktualizacja animateFrames aby używała deltaTime
    animateFrames(deltaTime = 0) {
        // Dodaj delta time do timera animacji
        this.animTimer += deltaTime
        
        // Sprawdź czy czas na nową klatkę
        if (this.animTimer >= this.frameDuration) {
            // Przejdź do następnej klatki
            if (this.framesCurrent < this.framesMax - 1) {
                this.framesCurrent++
            } else {
                this.framesCurrent = 0
            }
            
            // Zresetuj timer (zachowaj resztę dla płynności animacji)
            this.animTimer %= this.frameDuration
        }
    }

    update(deltaTime = 0) {
        this.draw()
        this.animateFrames(deltaTime)
    }
}

class Fighter extends Sprite {
    constructor({
        position,
        velocity,
        color = 'red',
        imageSrc,
        scale = 1,
        framesMax = 1,
        offset = {x:0, y:0},
        sprites,
        attackBox = { offset: {}, width: undefined, height: undefined}
    }) {
        super({
            position,
            imageSrc,
            scale,
            framesMax,
            offset
        });
        this.velocity = velocity;
        this.width = 50;
        this.height = 150;
        this.lastKey;
        this.attackBox = {
            position: {
                x: this.position.x,
                y: this.position.y
            },
            offset: attackBox.offset,
            width: attackBox.width,
            height: attackBox.height
        };
        this.color = color;
        this.isAttacking = false;
        this.health = 100;
        this.framesCurrent = 0;
        this.framesElapsed = 0;
        this.sprites = sprites;
        this.dead = false;
        this.win = false;
        
        // Nowe zmienne dla systemu ataku
        this.attackCooldown = 0;        // Aktualny cooldown ataku
        this.attackCooldownMax = ATTACK_COOLDOWN;  // Maksymalny cooldown ataku w sekundach
        this.attackReady = true;        // Czy atak jest gotowy
        this.attackQueued = false;      // Czy atak jest w kolejce
        this.lastAttackButtonState = false;  // Stan przycisku ataku w poprzedniej klatce
        this.attackTimeout = null;      // Przechowuje identyfikator timera ataku
        
        for (const sprite in this.sprites) {
            sprites[sprite].image = new Image();
            sprites[sprite].image.src = sprites[sprite].imageSrc;
        }
    }
    
    // Nowa metoda do aktualizacji cooldownu ataku
    updateAttackCooldown(deltaTime) {
        if (!this.attackReady) {
            this.attackCooldown -= deltaTime;
            if (this.attackCooldown <= 0) {
                this.attackReady = true;
                this.attackCooldown = 0;
                
                // Jeśli atak jest w kolejce I nadal trzymany jest przycisk ataku, wykonaj go
                // To zapobiegnie automatycznemu powtarzaniu ataków po pierwszym
                if (this.attackQueued && 
                    ((this === player && keys.space && keys.space.pressed) || 
                     (this === enemy && keys.ArrowDown && keys.ArrowDown.pressed))) {
                    this.attack();
                    this.attackQueued = false;
                } else {
                    // Jeśli przycisk nie jest wciśnięty, anuluj kolejkowany atak
                    this.attackQueued = false;
                }
            }
        }
    }
    
    // Zmodyfikowana metoda attack
    attack() {
        // Tylko jeśli atak jest gotowy
        if (!this.attackReady) return;
        
        // Wykonaj atak
        this.switchSprite('attack1');
        
        // Nie rozpoczynaj ataku w trakcie otrzymywania ciosu lub śmierci
        if (this.image === this.sprites.takeHit.image &&
            this.framesMax === this.sprites.takeHit.framesMax) {
            return;
        } else if (this.image === this.sprites.death.image &&
            this.framesMax === this.sprites.death.framesMax) {
            return;
        } else {
            // Ustawienie flagi ataku i cooldownu
            this.isAttacking = false; // Najpierw zresetuj
    
            // Ustawienie pojedynczego timera dla ataku
            if (!this.attackTimeout) {
                this.attackTimeout = setTimeout(() => {
                    if (this.image === this.sprites.attack1.image && 
                        this.framesCurrent >= 1) {
                        this.isAttacking = true;
                    }
                    // Wyczyść timeout po użyciu
                    this.attackTimeout = null;
                }, 50);
            }
            
            // Zablokuj możliwość ataku przez określony czas
            this.attackReady = false;
            this.attackCooldown = this.attackCooldownMax;
            
            // Dodajemy flagę, która zapobiega automatycznemu kolejkowaniu następnego ataku
            this.attackQueued = false;
        }
    }
    
    // Nowa metoda do próby wykonania ataku
    tryAttack() {
        if (this.attackReady) {
            // Jeśli atak jest gotowy, wykonaj go natychmiast
            this.attack();
        } else {
            // Jeśli przycisk został właśnie wciśnięty (nie był trzymany wcześniej),
            // zakolejkuj atak, jeśli cooldown jest bliski zakończeniu
            // Sprawdzanie czy to pierwszy raz kiedy przycisk został wciśnięty zapobiega zakolejkowaniu
            // podczas ciągłego trzymania przycisku
            if (!this.lastAttackButtonState && this.attackCooldown < this.attackCooldownMax / 2) {
                this.attackQueued = true;
            }
        }
        
        // Zapamiętaj stan przycisku ataku dla tej postaci
        if (this === player) {
            this.lastAttackButtonState = keys.space.pressed;
        } else {
            this.lastAttackButtonState = keys.ArrowDown.pressed;
        }
    }
    
    // Zmodyfikowana metoda update
    update(deltaTime = 0) {
        this.draw();
        
        if (!this.dead && !this.win) {
            // Animuj klatkę
            this.animateFrames(deltaTime);
            
            // Logika zarządzania stanem ataku
            if (this.attackInProgress) {
                // Aktywacja hitboxa ataku w odpowiednich klatkach (2-4)
                if (this.image === this.sprites.attack1.image) {
                    if (this.framesCurrent >= 2 && this.framesCurrent <= 4) {
                        this.isAttacking = true; // Aktywuj kolizję ataku tylko w klatkach 2-4
                    } else {
                        this.isAttacking = false; // Deaktywuj kolizję poza klatkach aktywnego ataku
                    }
                    
                    // Sprawdź czy animacja ataku się zakończyła
                    if (this.framesCurrent === this.sprites.attack1.framesMax - 1) {
                        // Jeśli doszliśmy do ostatniej klatki, oznacz animację jako zakończoną
                        this.attackAnimationComplete = true;
                        this.attackInProgress = false;
                        this.isAttacking = false;
                        
                        // KLUCZOWA ZMIANA: Natychmiast resetuj attackReady, aby umożliwić kolejne ataki
                        this.attackReady = true;
                        this.attackCooldown = 0;
                    }
                } else {
                    // Jeśli zmieniliśmy animację (np. na skok), przerwij stan ataku
                    this.attackInProgress = false;
                    this.isAttacking = false;
                    
                    // Również resetuj flagę ataku, gdy animacja zostanie przerwana
                    this.attackReady = true;
                    this.attackCooldown = 0;
                }
            }
            
            // Aktualizacja cooldownu ataku - zachowaj tę logikę, aby zapewnić minimalny czas między atakami
            if (!this.attackReady) {
                this.attackCooldown -= deltaTime;
                if (this.attackCooldown <= 0) {
                    this.attackReady = true;
                    this.attackCooldown = 0;
                }
            }
        }
        
        // Standardowa aktualizacja pozycji
        this.attackBox.position.x = this.position.x + this.attackBox.offset.x;
        this.attackBox.position.y = this.position.y + this.attackBox.offset.y;
        
        this.position.x += this.velocity.x;
        this.position.y += this.velocity.y;
        
        // Grawitacja
        if (this.position.y + this.height + this.velocity.y >= canvas.height - 64) {
            this.velocity.y = 0;
            this.position.y = 362;
        } else if (this.position.y <= 66) {
            this.velocity.y = (GRAVITY + 300) * deltaTime;
        } else {
            this.velocity.y += GRAVITY * deltaTime;
        }
    }
    
    takeHit() {
        this.health -= 10;

        if (this.health <= 0) {
            this.switchSprite('death');
        } else {
            this.switchSprite('takeHit');
        }
        
        // Knockback when hit
        if (this === player) {
            player.position.x -= 15;
        } else {
            enemy.position.x += 15;
        }
    }

    playerWin() {
        if (enemy.dead && player.image === player.sprites.win.image) {
            if (player.framesCurrent === player.sprites.win.framesMax - 1)
                this.win = true;
            return;
        }
    }
    
    // Zmodyfikowana metoda switchSprite
    switchSprite(sprite) {
        if(this.image === this.sprites.death.image ) {
            if (this.framesCurrent === this.sprites.death.framesMax - 1)
                this.dead = true;
            return;
        }
        
        // Sprawdzanie czy jesteśmy w trakcie animacji ataku
        // Jeśli tak, nie przerywamy animacji, chyba że to jest próba rozpoczęcia nowego ataku
        if (
            this.image === this.sprites.attack1.image &&
            this.framesCurrent < this.sprites.attack1.framesMax - 1 &&
            sprite !== 'attack1'
        ) return;
        
        // Nie przerywaj animacji otrzymywania obrażeń
        if (
            this.image === this.sprites.takeHit.image &&
            this.framesCurrent < this.sprites.takeHit.framesMax - 1 
        ) return;

        switch (sprite) {
            case 'idle':
                if (this.image !== this.sprites.idle.image){
                    this.image = this.sprites.idle.image;
                    this.framesMax = this.sprites.idle.framesMax;
                    this.framesCurrent = 0;
                }
                break;
            case 'idleHurt':
                if (this.image !== this.sprites.idleHurt.image){
                    this.image = this.sprites.idleHurt.image;
                    this.framesMax = this.sprites.idleHurt.framesMax;
                    this.framesCurrent = 0;
                }
                break;
            case 'idleHurtBadly':
                if (this.image !== this.sprites.idleHurtBadly.image){
                    this.image = this.sprites.idleHurtBadly.image;
                    this.framesMax = this.sprites.idleHurtBadly.framesMax;
                    this.framesCurrent = 0;
                }
                break;
            case 'idleHurtBadly2':
                if (this.image !== this.sprites.idleHurtBadly2.image){
                    this.image = this.sprites.idleHurtBadly2.image;
                    this.framesMax = this.sprites.idleHurtBadly2.framesMax;
                    this.framesCurrent = 0;
                }
                break;
            case 'idleHurtBadly3':
                if (this.image !== this.sprites.idleHurtBadly3.image){
                    this.image = this.sprites.idleHurtBadly3.image;
                    this.framesMax = this.sprites.idleHurtBadly3.framesMax;
                    this.framesCurrent = 0;
                }
                break;
            case 'run':
                if (this.image !== this.sprites.run.image){
                    this.image = this.sprites.run.image;
                    this.framesMax = this.sprites.run.framesMax;
                    this.framesCurrent = 0;
                }
                break;
            case 'jump':
                if (this.image !== this.sprites.jump.image){
                    this.image = this.sprites.jump.image;
                    this.framesMax = this.sprites.jump.framesMax;
                    this.framesCurrent = 0;
                }
                break;
            case 'fall':
                if (this.image !== this.sprites.fall.image){
                    this.image = this.sprites.fall.image;
                    this.framesMax = this.sprites.fall.framesMax;
                    this.framesCurrent = 0;
                }
                break;
            case 'attack1':
                if (this.image !== this.sprites.attack1.image &&
                     this.image !== this.sprites.takeHit.image &&
                     this.image !== this.sprites.death.image){
                    this.image = this.sprites.attack1.image;
                    this.framesMax = this.sprites.attack1.framesMax;
                    this.framesCurrent = 0;
                }
                break;
            case 'takeHit':
                if (this.image !== this.sprites.takeHit.image){
                    this.image = this.sprites.takeHit.image;
                    this.framesMax = this.sprites.takeHit.framesMax;
                    this.framesCurrent = 0;
                }
                break;
            case 'death':
                if (this.image !== this.sprites.death.image){
                    this.image = this.sprites.death.image;
                    this.framesMax = this.sprites.death.framesMax;
                    this.framesCurrent = 0;
                    player.offset.y = 128;
                }
                break;
            case 'win':
                if (this.image !== this.sprites.win.image && enemy.image === enemy.sprites.death.image){
                    this.image = this.sprites.win.image;
                    this.framesMax = this.sprites.win.framesMax;
                    this.framesCurrent = 0;
                    player.offset.y = 105;
                }
                break;
        }
    }
}