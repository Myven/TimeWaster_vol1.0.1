<?php
include_once 'header.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <div class="homepage">
    <h1>HOMEPAGE TESTING THE LONDON LOOK</h1>

    </div>
        <div class="accAdv">
            <?php
                if(isset($_SESSION["useruid"]))
                {
                    echo "<h3>Welcome in our homepage " . $_SESSION["useruid"] . "!</h3>";
                    echo "<p>Now you got acces to our fantastic <a href=gameSection.php>GAMING SECTION</a></p>";
                }
                else
                {
                    echo "<p>Want to use our website? You need to be <a href='login.php'>logged in!</a></p>";
                    echo "<p>Haven't got an accout yet? <a href='signup.php'>Create one!</a></p>";
                }
            ?>
        </div>
        <?php
            include_once 'footer.php';
        ?>

</body>
</html>
