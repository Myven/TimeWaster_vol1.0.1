
</body>
</html>

<script src="js/script.js"></scirpt>